import setuptools

setuptools.setup(
    name="my-test-package",
    version="1.0",
    zip_safe=True,
)
